# HANDCRAFT — Har Kala Mein Ek Kahani

A working storefront and store desk for handmade Gujarati Lippan art, built around the five artwork photos supplied with the brief. It includes responsive customer pages, a real Node.js HTTP server, a persistent SQLite database, customer/admin authentication, server-priced carts and orders, custom-art enquiries, coupon management, image uploads, email hooks, and a Razorpay test-mode integration.

> **Preview-shop notice:** catalogue prices, compare-at prices, shipping settings, product dimensions and stock are starter/sample values. Review and replace them before taking real orders. No real customer reviews, sales statistics, business contact details or delivery promises are seeded.

## Run locally

Requirements: Node.js 22.5+ (Node 24 recommended; `node:sqlite` is used, so no package installation is needed).

```sh
cp .env.example .env
# Set a long random value for ADMIN_SETUP_TOKEN before first run.
# Example: openssl rand -hex 32
npm run dev
```

Open `http://localhost:3000`. The first run creates `data/handcraft.sqlite` and seeds the editable sample catalogue and ten requested categories. Visit `/setup-admin` while `ADMIN_SETUP_TOKEN` is set and create the first administrator. Then **remove `ADMIN_SETUP_TOKEN` from `.env` and restart**. Setup is one-time; there is no hardcoded admin password.

`npm start` runs without watch mode. Database tables are created from `schema.sql` on startup. `.env` and SQLite database files are excluded from Git.

## What works

- Responsive, accessible home/shop/product/cart/checkout/account/custom-order/story/contact pages with sticky navigation, search, category/price/availability filters, sorting, pagination, wishlist, saved addresses, profile updates and a mobile menu.
- Database-backed product/category inventory, customer records, addresses, carts, orders, order items, coupons, wishlist entries, moderated verified-buyer reviews, newsletter sign-ups and private custom-order enquiries. Customers can request cancellation while an order is still eligible; paid-order refunds remain a manual store/payment-provider step.
- Guest and signed-in carts use server-stored records. The server recalculates prices, discounts, stock and totals at checkout; idempotency keys prevent duplicate order creation when a checkout request is retried.
- Local development has a clearly labelled **test order** option. It saves an order but takes no money; it is disabled in production. Cash on delivery is disabled until the store owner explicitly enables it.
- Admin routes check the administrator role on the server. Manage products, categories, orders/status/tracking, custom requests/quotations, coupons, reviews, customers and subscribers. Product/enquiry reference-image uploads are type/size checked; custom references remain private and admin-only.
- Passwords are scrypt-hashed. Sessions use HttpOnly/SameSite cookies (Secure in production); mutating requests check their origin; authentication/reset/enquiry/newsletter endpoints have per-process rate limits. Errors are returned without leaking stack traces.
- SEO titles/descriptions/canonical URLs, product metadata, `sitemap.xml`, `robots.txt`, image alt text, loading/error states, and a custom 404 page.

## Configure before taking real orders

### Razorpay test mode

1. Create Razorpay **test-mode** credentials in your Razorpay account.
2. Set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` in the server environment. Never put the secret in browser code or commit it.
3. Set `RAZORPAY_WEBHOOK_SECRET`; point the Razorpay webhook at `https://YOUR-DOMAIN/api/webhooks/razorpay` and subscribe to `payment.captured`, `payment.failed` and `order.paid`.
4. Set `BASE_URL` to the HTTPS storefront origin. Exercise a complete test payment and confirm the captured order/webhook before considering payments ready.

The server creates provider orders, verifies the checkout HMAC, fetches the payment from Razorpay, checks currency/order/amount, captures authorized payments, verifies webhook HMACs, de-duplicates webhook events, and avoids duplicate local checkout submissions. Failed/cancelled payments restore the cart when a failure/cancel can be confirmed. **No Razorpay credentials are included or configured here; real payments have not been tested.**

### Email

Optional transactional email uses the Resend HTTP API. Set `RESEND_API_KEY`, a verified `MAIL_FROM`, and (for custom-request notices) `STORE_NOTIFY_EMAIL`. Set `BASE_URL` for password-reset links. Without these values, password-reset email reports unavailable; order/custom-request records remain saved, and the UI does not claim an email was sent.

### Store-owned values

Edit the seed products in `server.js` or manage products in the admin dashboard. Change `STORE_SHIPPING_FEE_PAISE` and `STORE_FREE_SHIPPING_THRESHOLD_PAISE`; turn on `COD_ENABLED=true` only if the store supports COD. Seed stock is deliberately **made-to-order with no invented quantity**. Add actual inventory numbers for stocked goods.

## Tests

```sh
npm test
```

The Node test suite exercises catalog search/filters, server-side totals, coupons, guest/customer orders, idempotent checkout replay, registration/password hashing, admin setup/authorization, category/product management, private enquiry records, payment-not-configured behavior, cart restoration and SEO endpoints. Browser QA was also run in Chromium for desktop/mobile layout, menu, shopping/cart/checkout, registration, wishlist/profile, admin setup and category/product forms.

## Deployment notes and current limits

- This project deliberately uses a **single-process Node.js + SQLite** architecture, rather than Next.js/TypeScript/Tailwind/Prisma/PostgreSQL. No pre-existing project was available and the sandbox had no Next.js/Prisma/PostgreSQL client dependencies; this stack keeps the website runnable here without downloading dependencies. The site CSS is standalone and the application uses Node built-ins.
- SQLite WAL works for a **single persistent app instance**. Keep the database and `data/uploads` on durable storage, back them up, and do not run multiple app replicas against an ephemeral/local filesystem. For a multi-instance/high-volume store, migrate to PostgreSQL and an external session/rate-limit store before scaling; a PostgreSQL/Prisma adapter is not included in this deliverable.
- Put the Node server behind a TLS-terminating reverse proxy, set `NODE_ENV=production`, `BASE_URL=https://YOUR-DOMAIN`, use a durable writable disk for the database/uploads, configure backups/logging, and provision environment secrets through the deployment platform (not a committed `.env`). The production flag disables test checkout and enables Secure cookies/HSTS.
- Image uploads currently use local disk. The app does not yet connect Cloudinary/object storage; use persistent storage or add a managed media provider before deploying to ephemeral serverless hosting.
- Product catalogue/category/order tools are database-backed. Homepage hero/banner editing and store-policy editing are not separate admin forms yet; the starter home content lives in `public/assets/app.js`, while shipping/COD/payment settings are environment-based.
- Rate limits are in-memory and are per process. Use a shared rate-limit store for multiple replicas. Email sending, real Razorpay payments, shipping serviceability/estimates, refunds and a carrier integration require the relevant store credentials/services and operational testing.
- Privacy/terms copy is intentionally preview wording. Replace it with store-reviewed customer policies before launch.

## Project layout

```text
handcraft/
├── server.js                 # Node HTTP server, API, auth, checkout, Razorpay + email hooks
├── schema.sql                # SQLite tables, constraints and indexes
├── test/store.test.js        # API journey/security integration tests
├── public/
│   ├── index.html            # storefront shell
│   ├── 404.html
│   ├── assets/app.js          # client routing, product/account/admin UI
│   ├── assets/style.css       # responsive premium Lippan-inspired design
│   └── images/*.webp         # optimized versions of the supplied artwork
├── data/                     # generated SQLite database + private enquiry uploads
├── .env.example
└── README.md
```


## Deploy on Render (persistent SQLite)

This app is a Node.js server that uses SQLite; it is not a static-only Netlify site. The included `render.yaml` configures a Render web service and a persistent disk mounted at `/opt/render/project/src/data`, so the SQLite database and uploaded reference files can persist across deploys. A persistent disk requires a paid Render service plan; do not use an ephemeral/free service for real customer orders.

1. Push the contents of this project to a GitHub repository.
2. In Render, choose **New → Blueprint**, connect that repository, and apply `render.yaml`.
3. When prompted, set `ADMIN_SETUP_TOKEN` to a long random one-time value. After the first deploy, open the deployed HTTPS site and visit `/setup-admin` to create the first administrator.
4. After creating the administrator, remove `ADMIN_SETUP_TOKEN` from the Render environment and redeploy.
5. Set `BASE_URL` in Render to the actual deployed HTTPS URL before enabling password-reset email. Configure Razorpay credentials only when ready to test payments.

Do not upload `.env`, database files, or any service-role/API secret to GitHub. The existing Supabase project is not connected by this version of the app; its server uses SQLite, so do not assume Supabase is storing orders.
