import { before, after, test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createServer } from '../server.js';

let server, base, temp;
const jars={guest:[],customer:[],admin:[]};
before(async()=>{
  process.env.NODE_ENV='development';
  process.env.ADMIN_SETUP_TOKEN='test-setup-token-not-for-production';
  process.env.COD_ENABLED='false';
  process.env.RAZORPAY_KEY_ID='';process.env.RAZORPAY_KEY_SECRET='';
  temp=fs.mkdtempSync(path.join(os.tmpdir(),'handcraft-test-'));
  server=createServer({dbPath:path.join(temp,'test.sqlite')});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  base=`http://127.0.0.1:${server.address().port}`;
});
after(async()=>{if(server)await new Promise(resolve=>server.close(resolve));server?.db.close();if(temp)fs.rmSync(temp,{recursive:true,force:true});});
async function call(who,url,options={}){
  const headers={Origin:base,...(options.headers||{})};
  if(options.body!==undefined)headers['Content-Type']='application/json';
  if(['POST','post'].includes(options.method||'GET')&&['/api/checkout','/api/payments/razorpay/order'].includes(url.split('?')[0]))headers['Idempotency-Key']=options.headers?.['Idempotency-Key']||randomUUID();
  if(jars[who]?.length)headers.Cookie=jars[who].map(x=>x.split(';')[0]).join('; ');
  const r=await fetch(base+url,{...options,headers,body:options.body===undefined?undefined:JSON.stringify(options.body)});
  for(const c of r.headers.getSetCookie?.()||[]){const name=c.split('=',1)[0];jars[who]=jars[who].filter(x=>x.split('=',1)[0]!==name);jars[who].push(c);}
  const data=(r.headers.get('content-type')||'').includes('json')?await r.json():await r.text();
  return {r,data};
}
function ok(result,status=200){assert.equal(result.r.status,status,JSON.stringify(result.data));return result.data;}

test('HANDCRAFT store journeys, server validation, and admin authorization',async()=>{
  ok(await call('guest','/api/health'));
  const config=ok(await call('guest','/api/config'));assert.equal(config.brand,'HANDCRAFT');assert.equal(config.demoCheckout,true);
  const categories=ok(await call('guest','/api/categories'));assert.equal(categories.length,10);
  const search=ok(await call('guest','/api/products?q=Ganesha'));assert.equal(search.items.length,1);assert.equal(search.items[0].name,'Ganesha in Turquoise');
  const filtered=ok(await call('guest','/api/products?category=festive-collection&sort=price-low'));assert.equal(filtered.total,1);
  assert.equal((await call('guest','/not-a-real-route')).r.status,404);
  const p=search.items[0];
  let cart=ok(await call('guest','/api/cart/items',{method:'POST',body:{productId:p.id,quantity:2,clientPricePaise:1}}));
  assert.equal(cart.subtotalPaise,p.price_paise*2,'server calculates cart totals from database prices');
  assert.equal(cart.items[0].quantity,2);
  cart=ok(await call('guest','/api/cart/items',{method:'PATCH',body:{productId:p.id,quantity:1,customization:''}}));assert.equal(cart.items[0].quantity,1);
  assert.equal((await call('guest','/api/cart/coupon',{method:'POST',body:{code:'NOT-A-COUPON'}})).r.status,400);
  const checkoutBody={paymentMethod:'test',name:'Guest Customer',email:'guest@example.test',phone:'+919876543210',address:'12 Craft Lane',city:'Ahmedabad',state:'Gujarat',pincode:'380001',country:'India',unitPricePaise:1};
  const testOrderKey=randomUUID();
  const testOrder=ok(await call('guest','/api/checkout',{method:'POST',headers:{'Idempotency-Key':testOrderKey},body:checkoutBody}),201);
  assert.equal(testOrder.order.payment_status,'not_required');assert.match(testOrder.order.order_number,/^HC-/);assert.equal(testOrder.order.total_paise,p.price_paise);
  const replay=ok(await call('guest','/api/checkout',{method:'POST',headers:{'Idempotency-Key':testOrderKey},body:checkoutBody}),201);assert.equal(replay.order.order_number,testOrder.order.order_number);
  assert.equal((await call('guest','/api/account/orders')).r.status,401);
  assert.equal((await call('guest','/api/admin/overview')).r.status,401);
  const enquiry=ok(await call('guest','/api/enquiries',{method:'POST',body:{name:'Asha Patel',email:'asha@example.test',phone:'+919800000000',productType:'Nameplate',dimensions:'30 cm',colors:'Terracotta and cream',description:'A personalised entryway nameplate with a floral border.',budget:'5000'}}),201);
  assert.equal(enquiry.notification,'not_configured');
  const registered=ok(await call('customer','/api/register',{method:'POST',body:{name:'Neha Customer',email:'neha@example.test',phone:'+919811111111',password:'This-Is-A-Safe-Test-Password-92'}}),201);
  assert.equal(registered.user.role,'customer');assert.equal(registered.emailStatus,'not_configured');
  const userRow=server.db.prepare('SELECT password_hash FROM users WHERE id=?').get(registered.user.id);assert.match(userRow.password_hash,/^scrypt:/);assert.doesNotMatch(userRow.password_hash,/This-Is-A-Safe/);
  assert.equal((await call('customer','/api/admin/products')).r.status,403);
  const merged=ok(await call('customer','/api/cart'));assert.equal(merged.items.length,0);
  const setup=ok(await call('admin','/api/admin/setup',{method:'POST',body:{name:'Store Admin',email:'admin@example.test',password:'Another-Safe-Admin-Password-2026',setupToken:process.env.ADMIN_SETUP_TOKEN}}),201);
  assert.equal(setup.user.role,'admin');assert.equal((await call('guest','/api/admin/setup',{method:'POST',body:{}})).r.status,403);
  const overview=ok(await call('admin','/api/admin/overview'));assert.equal(overview.orders,1);assert.equal(overview.customers,1);assert.equal(overview.revenuePaise,0);
  const allEnquiries=ok(await call('admin','/api/admin/enquiries'));assert.equal(allEnquiries.length,1);assert.equal(allEnquiries[0].name,'Asha Patel');
  const updatedEnquiry=ok(await call('admin',`/api/admin/enquiries/${allEnquiries[0].id}`,{method:'PUT',body:{status:'quoted',quoteRupees:'4900',adminNotes:'Confirm dimensions with customer'}}));assert.equal(updatedEnquiry.ok,true);
  const products=ok(await call('admin','/api/admin/products'));assert.equal(products.length,5);
  const created=ok(await call('admin','/api/admin/products',{method:'POST',body:{sku:'HC-TEST-100',name:'Test Artwork',description:'A test product for backend validation.',priceRupees:1800,category:'traditional-lippan-art',image:'/images/jagannath-art.webp',availability:'made_to_order',stockQuantity:null,featured:true}}),201);
  assert.equal(created.product.price_paise,180000);
  const beforeCouponCart=ok(await call('customer','/api/cart/items',{method:'POST',body:{productId:p.id,quantity:1}}));assert.equal(beforeCouponCart.items[0].quantity,1);
  const coupon=ok(await call('admin','/api/admin/coupons',{method:'POST',body:{code:'CRAFT10',discountType:'percent',amount:10,minimumOrderRupees:0,maxUses:2}}),201);
  const discounted=ok(await call('customer','/api/cart/coupon',{method:'POST',body:{code:'CRAFT10'}}));assert.equal(discounted.discountPaise,Math.floor(p.price_paise*0.1));assert.equal(discounted.couponCode,'CRAFT10');
  const customerOrders=ok(await call('customer','/api/checkout',{method:'POST',body:{paymentMethod:'test',name:'Neha Customer',email:'neha@example.test',phone:'+919811111111',address:'8 Art Road',city:'Surat',state:'Gujarat',pincode:'395003'}}),201);assert.equal(customerOrders.order.user_id,registered.user.id);
  const history=ok(await call('customer','/api/account/orders'));assert.equal(history.length,1);assert.equal(history[0].order_number,customerOrders.order.order_number);
  const cancellation=ok(await call('customer',`/api/account/orders/${customerOrders.order.id}/cancel`,{method:'POST',body:{}}));assert.equal(cancellation.status,'cancelled');
  const orderRow=server.db.prepare('SELECT id FROM orders WHERE order_number=?').get(testOrder.order.order_number);
  const update=ok(await call('admin',`/api/admin/orders/${orderRow.id}`,{method:'PUT',body:{status:'processing',trackingCarrier:'',trackingNumber:''}}));assert.equal(update.order.status,'processing');
  const imageBad=await call('admin','/api/admin/images',{method:'POST',body:{image:'data:text/plain;base64,SGVsbG8='}});assert.equal(imageBad.r.status,400);
  const forbiddenOrigin=await fetch(base+'/api/login',{method:'POST',headers:{Origin:'https://attacker.invalid','Content-Type':'application/json'},body:JSON.stringify({email:'admin@example.test',password:'no'})});assert.equal(forbiddenOrigin.status,403);
  ok(await call('guest','/api/cart/items',{method:'POST',body:{productId:p.id,quantity:1}}));
  assert.equal((await call('guest','/api/payments/razorpay/order',{method:'POST',body:{name:'Guest',email:'guest2@example.test',phone:'+919811111111',address:'8 Road',city:'Surat',state:'Gujarat',pincode:'395003'}})).r.status,503);
  const restoredCart=ok(await call('guest','/api/cart'));assert.equal(restoredCart.items.length,1,'failed payment setup puts cart items back');
  const sitemap=await fetch(base+'/sitemap.xml');assert.equal(sitemap.status,200);assert.match(await sitemap.text(),/<urlset/);
  const robot=await fetch(base+'/robots.txt');assert.equal(robot.status,200);
  assert.ok(coupon.id);
});
